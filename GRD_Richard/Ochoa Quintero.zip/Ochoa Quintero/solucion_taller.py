import os
import csv


def listar_archivos_directorio():
    """Punto 1: Lista el nombre, extensión y ruta de los archivos en la carpeta actual."""
    print("=== 1. LISTADO DE ARCHIVOS EN EL DIRECTORIO ===")

    # Obtenemos la ruta de la carpeta donde está ejecutándose este script
    ruta_actual = os.getcwd()

    # Listamos todo lo que hay dentro de la carpeta
    archivos = os.listdir(ruta_actual)

    for archivo in archivos:
        # Verificamos que sea un archivo y no una subcarpeta
        if os.path.isfile(os.path.join(ruta_actual, archivo)):
            # Separamos el nombre de la extensión
            nombre_base, extension = os.path.splitext(archivo)
            ruta_completa = os.path.abspath(archivo)

            print(f"Nombre: {nombre_base}")
            print(f"Extensión: {extension}")
            print(f"Ruta: {ruta_completa}")
            print("-" * 40)
    print("\n")


def procesar_usuarios_csv(nombre_archivo):
    """Punto 2 y 3: Lee el archivo CSV y muestra los datos específicos solicitados."""
    print("=== 2 Y 3. PROCESAMIENTO DE USUARIOS.CSV ===")

    # Verificamos si el archivo realmente existe antes de abrirlo (Buena práctica)
    if not os.path.exists(nombre_archivo):
        print(f"Error: El archivo {nombre_archivo} no se encuentra.")
        return

    # Abrimos el archivo CSV indicando que el delimitador es ';'
    with open(nombre_archivo, mode="r", encoding="utf-8") as archivo_csv:
        lector = csv.reader(archivo_csv, delimiter=";")

        # Leer la primera línea (cabecera) para saber los nombres de las columnas
        cabeceras = next(lector)
        total_columnas = len(cabeceras)

        print(f"Leyendo contenido de '{nombre_archivo}'...\n")

        # Recorremos cada fila de usuarios
        for fila in lector:
            # Para evitar errores si hay una línea vacía
            if not fila:
                continue

            # Mapeamos las columnas según la estructura del taller:
            # Index: 1=Nombres, 2=Apellidos, 3=Dependencia, 4=Área, 5=Piso 6=Teléfono, 7=Correo, 8=Empresa, 9=Ciudad, 10=Estado
            nombres = fila[1]
            apellidos = fila[2]
            dependencia = fila[3]
            area = fila[4]
            piso = fila[5]
            telefono = fila[6]
            correo = fila[7]
            empresa = fila[8]
            ciudad = fila[9]
            estado = fila[10]

            # Imprimimos los requerimientos del punto 3
            print(f"Usuario: {nombres} {apellidos}")
            print(f"  - Dependencia: {dependencia}")
            print(f"  - Área: {area}")
            print(f"  - Piso: {piso}")
            print(f"  - Teléfono: {telefono}")
            print(f"  - Correo: {correo}")
            print(f"  - Empresa: {empresa}")
            print(f"  - Ciudad: {ciudad}")
            print(f"  - Estado: {estado}")
            print(f"  - Total Columnas Registradas: {total_columnas}")
            print("-" * 40)


# --- Bloque Principal ---
if __name__ == "__main__":
    # 1. Obtener la ruta absoluta del directorio donde está guardado ESTE script
    # Usamos os.path.realpath para resolver correctamente los enlaces de iCloud en Mac
    ruta_del_script = os.path.dirname(os.path.realpath(__file__))

    # 2. Forzar a Python a cambiar su directorio de trabajo a la carpeta del script
    os.chdir(ruta_del_script)

    # 3. Ejecutar el listado de archivos (ahora listará con precisión esta carpeta)
    listar_archivos_directorio()

    # 4. Buscamos el archivo "Usuarios". 
    # Como vimos en la captura anterior que tu archivo no tiene la extensión .csv visible en el nombre,
    # primero verificamos si existe como "Usuarios" y si no, como "Usuarios.csv".
    if os.path.exists(os.path.join(ruta_del_script, "Usuarios")):
        nombre_real_csv = "Usuarios"
    else:
        nombre_real_csv = "Usuarios.csv"

    ruta_completa_csv = os.path.join(ruta_del_script, nombre_real_csv)

    # 5. Ejecutar la lectura del CSV con la ruta exacta encontrada
    procesar_usuarios_csv(ruta_completa_csv)